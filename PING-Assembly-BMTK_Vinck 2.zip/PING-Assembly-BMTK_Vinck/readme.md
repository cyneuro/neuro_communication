## Run Instructions

``` python
python build_network.py
python update_configs.py
nrniv -python run_bionet.py config.json
```